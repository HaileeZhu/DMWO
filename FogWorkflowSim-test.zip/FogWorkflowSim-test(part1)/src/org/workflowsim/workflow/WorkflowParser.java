package workflow;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

public class WorkflowParser {
	public static List<Task> parseXMLFile(String file) throws Exception{
		List<Task> list = new ArrayList<>();
		
		MyDAXReader daxReader = new MyDAXReader();
		SAXParser sp = SAXParserFactory.newInstance().newSAXParser();
		sp.parse(new InputSource(file), daxReader);
		for(Task t: daxReader.getNameTaskMapping().values())
			list.add(t);
		addDummyTasks(list);
		
		// Bind transfer data flow to control flow, i.e., setDataSize for an edge
		HashMap<String, TransferData> transferData = daxReader.getTransferData();
		
		Task tentry = list.get(0);
		Task texit = list.get(list.size() - 1);
		for(TransferData td : transferData.values()){	//Bind data flow to control flow
			Task source = td.getSource();
			List<Task> destinations = td.getDestinations();
			if(source == null){
				source = tentry;
				//td.setSize(0);		//a setting: transfer time of input data is omitted --- setting to 0
			}
			if( destinations.size()==0)	
				destinations.add(texit);
			for(Task destination : destinations){
				boolean flag = true;
				for(Edge outEdge : source.getOutEdges()){
					if(outEdge.getDestination() == destination){
						outEdge.setDataSize(td.getSize());			//bind here
						flag = false;
					}
				}
				//an annoying problem in some DAX files: a data flow cannot be bound to existing control flows
				//flag to indicate whether this problem exists
				if(flag == true){
					Edge e = new Edge(source, destination);
					e.setDataSize(td.getSize());
					source.insertOutEdge(e);
					destination.insertInEdge(e);
					System.out.println("**************add a control flow*******************"
							+ "source: "+e.getSource().getIdName()+"; destination: "+ e.getDestination().getIdName() + "; transfer data size:" + e.getDataSize() + "; transfer data name:" + td.getName());
				}
			}
		}
		
		for (Task t : list) {
			for (Edge e : t.getOutEdges())
				System.out.println("transfer data source:"  + e.getSource().getIdName() + ", id:" + e.getSource().getId() 
						+ "; transfer data destination:" + e.getDestination().getIdName() + ", id:" +e.getDestination().getId() + "; transfer data:" + e.getDataSize());
		}
		
		return list;
	}

	//note weight values here are multiplied by VM.SPEEDS or NETWORK_SPEED
	public static List<Task> parseDOTFile(String file) throws IOException {
		List<Task> list = new ArrayList<>();
		HashMap<String, Task> nameTaskMapping = new HashMap<String, Task>();
		
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        String vertexP = "([0-9A-Z]*)\\s*\\[label=\"\\1\\:([0-9]*)";
		String edgeP = "([0-9A-Z]*)\\s*->\\s*([0-9A-Z]*)\\s*\\[label=([0-9]*)\\];";
		Pattern vertexPattern = Pattern.compile(vertexP);
		Pattern edgePattern = Pattern.compile(edgeP);
		while((line=br.readLine())!=null){
			Matcher edgeM = edgePattern.matcher(line);
			Matcher vertexM = vertexPattern.matcher(line);
			if(vertexM.find()){
				String name = vertexM.group(1);
				double weight = Double.parseDouble(vertexM.group(2));
				Task t = new Task(name, weight*10); //10Hz=VM.SPEEDS[VM.FASTEST]
				nameTaskMapping.put(name, t);
			}else if(edgeM.find()){
				String name1 = edgeM.group(1);
				String name2 = edgeM.group(2);
				double weight = Double.parseDouble(edgeM.group(3));
				Task task1 = nameTaskMapping.get(name1);
				Task task2 = nameTaskMapping.get(name2);
				Edge e = new Edge(task1, task2);
				e.setDataSize((long)(weight*2)); //2Mbps=VM.NETWORK_SPEED
				task1.insertOutEdge(e);
				task2.insertInEdge(e);
			}
		}
		for(Task t: nameTaskMapping.values())
			list.add(t);
		addDummyTasks(list);
		br.close();
		
		return list;
	}
	
	//-----------add two dummy tasks to this workflow----------------------
	private static void addDummyTasks(List<Task> list) {

		Task tentry = new Task(0, ("entry"), 0);	
		Task texit = new Task(("exit"), 0);
		
		for (Task tf: list) {
			if (tf.getIdName().equals("entry")) {
				tentry = tf;
				Collections.swap(list, list.indexOf(tentry), 0); //��entry����0��λ��
				tentry.setId(0); //��entry��id����Ϊ0
			}
			else if (tf.getIdName().equals("exit")) {
				texit = tf;
				Collections.swap(list, list.indexOf(texit), list.size()-1); //��exit�������һ��λ��
				texit.setId(list.size()); //��exit��id����Ϊ�б�β��
			}
			else if (list.get(0).equals(tentry)&list.get(list.size()-1).equals(texit)) {
				for (int i = 1; i < list.size(); i++)
					list.get(i).setId(list.get(i).getId()-1); //���������id���˳��-1
				return;
			}
			else {
				if(tf.getInEdges().size()==0){
					Edge e = new Edge(tentry, tf);
					tf.getInEdges().add(e);
					tentry.getOutEdges().add(e);
				}
				if(tf.getOutEdges().size()==0){
					Edge e = new Edge(tf, texit);
					tf.getOutEdges().add(e);
					texit.getInEdges().add(e);
				}
			}
				
		}
		list.add(0, tentry);
		list.add(texit);
		
		
/*		
		for (Task tf: list) { //����exit��list����entryǰ��ʱ����bug���޸�Ϊ�������
			if (tf.getIdName().equals("entry")) {
				Collections.swap(list, list.indexOf(tf), 0); //��entry����0��λ��
				list.get(0).setId(0); //��0��λ�õ�entry��id����Ϊ0
				for (int i = 1; i < list.size(); i++) { //���������id���˳��-1
					list.get(i).setId(list.get(i).getId()-1);
				}
				
				//System.out.println(list.get(0).getIdName()+","+list.get(0).getId());
			}
			if (tf.getIdName().equals("exit")) {
				Collections.swap(list, list.indexOf(tf), list.size() - 1); //��exit�������һ��λ��
				list.get(list.size()-1).setId(list.size()); //�����һ��λ�õ�exit��id����Ϊ�б�β��
				//System.out.println(list.get(list.size() - 1).getIdName()+","+list.get(list.size() - 1).getId());
				return;
			}
		}

		Task tentry = new Task(0, ("entry"), 0);	
		Task texit = new Task(("exit"), 0);
		for(Task t: list){						//add edges to entry and exit
			if(t.getInEdges().size()==0){
				Edge e = new Edge(tentry, t);
				t.getInEdges().add(e);
				tentry.getOutEdges().add(e);
			}
			if(t.getOutEdges().size()==0){
				Edge e = new Edge(t, texit);
				t.getOutEdges().add(e);
				texit.getInEdges().add(e);
			}
		}
		list.add(0, tentry);			//add the entry and exit nodes to the workflows
		list.add(texit); */
	}
}

class MyDAXReader extends DefaultHandler{		//this class is only used in parsing DAX data
	private HashMap<String, Task> nameTaskMapping = new HashMap<String, Task>();
	private HashMap<String, TransferData> transferData = new HashMap<String, TransferData>();

	private Stack<String> tags = new Stack<String>();
	private String childId;
	private Task lastTask;
	public void startElement(String uri, String localName, String qName, Attributes attrs) {
		if(qName.equals("job")){
			String id = attrs.getValue("id");
			if(nameTaskMapping.containsKey(id))		//id conflicts
				throw new RuntimeException();
			Task t = new Task(id, Double.parseDouble(attrs.getValue("runtime")));
			nameTaskMapping.put(id, t);
			lastTask = t;
		}
		else if(qName.equals("uses") && tags.peek().equals("job")){
			//After reading the element "job", the element "uses" means a trasferData (i.e., data flow)
			String filename =attrs.getValue("file");
				
			long fileSize = Long.parseLong(attrs.getValue("size"));
			TransferData td = transferData.get(filename);
			if(td == null){
				td = new TransferData(filename, fileSize);
			}
			if(attrs.getValue("link").equals("input")){
				td.addDestination(lastTask);
			}else{									//output
				td.setSource(lastTask);
			}
			transferData.put(filename, td);
		}
		else if(qName.equals("child") ){		
			childId = attrs.getValue("ref");
		}
		else if(qName.equals("parent") ){ 
			//After reading the element "child", the element "parent" means an edge (i.e., control flow)
			Task child = nameTaskMapping.get(childId);
			Task parent = nameTaskMapping.get(attrs.getValue("ref"));
			
			Edge e = new Edge(parent, child);			//control flow
			parent.insertOutEdge(e);
			child.insertInEdge(e);
		}
		tags.push(qName);
	}
	
	public void endElement(String uri, String localName,String qName) {
		tags.pop();
	}
	
	public HashMap<String, Task> getNameTaskMapping() {
		return nameTaskMapping;
	}
	
	public HashMap<String, TransferData> getTransferData() {
		return transferData;
	}
}

class TransferData{		//this class is only used in parsing DAX data
	private String name;
	private long size;
	private Task source;		//used to bind control flow and data flow
	private List<Task> destinations = new ArrayList<Task>();

	public TransferData(String name, long size) {
		this.name = name;
		this.size = size;
	}
	
	//-------------------------------------getters & setter--------------------------------
	public String getName() {return name;}
	public long getSize() {return size;}
	public Task getSource() {return source;}
	public void setSource(Task source) {this.source = source;}
	public void addDestination(Task t){destinations.add(t);}
	public List<Task> getDestinations() {return destinations;}
	public void setSize(long size) {
		this.size = size;
	}
	//-------------------------------------overrides--------------------------------
	public String toString() {return "TransferData [name=" + name + ", size=" + size + "]";}
}

