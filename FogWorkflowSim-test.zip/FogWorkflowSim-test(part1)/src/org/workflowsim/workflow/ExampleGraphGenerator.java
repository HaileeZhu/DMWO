package workflow;

import java.io.File;
import java.io.FileWriter;

/**
 * example graphs generator with a number of input data
 * @author zhh
 */
public class ExampleGraphGenerator {

	public static void main(String[] args) {
		
		ExampleGraphGenerator g = new ExampleGraphGenerator();
		String s = g.generateGraphFile("D:/eclipse-workspace/ZHH/src/DotDatasets/DCDSgraph.dot");
		GraphViz.writeDOTGraphToImageFile(s, "png", "D:/eclipse-workspace/ZHH/src/DotDatasets/DCDSgraph.png");
	}
		
	public String generateGraphFile(String outFile){
		String s = generateGraph();
		generateDOTFile(outFile, s);
		return s;
	}
		
	private void generateDOTFile(String outFile, String s) {
		try{
			FileWriter fw = new FileWriter(new File(outFile));
			fw.write(s);
			fw.flush();
			fw.close();
		}catch(Exception e){
			System.out.println("fails");
		}
	}
		
	public String generateGraph() {
		StringBuilder sb = new StringBuilder();
		sb.append("digraph {\n");
		sb.append("0 [label=\"vj,1:0\"];\n");
		sb.append("1 [label=\"vj,2:10\"];\n");
		sb.append("2 [label=\"vj,3:15\"];\n");
		sb.append("5 [label=\"vj,6:11\"];\n");
		sb.append("3 [label=\"vj,4:16\"];\n");
		sb.append("4 [label=\"vj,5:11\"];\n");
		sb.append("6 [label=\"vj,7:18\"];\n");
		sb.append("7 [label=\"vj,8:8\"];\n");
		sb.append("9 [label=\"vj,10:20\"];\n");
		sb.append("8 [label=\"vj,9:13\"];\n");		
		sb.append("10 [label=\"vj,11:10\"];\n");
		sb.append("11 [label=\"vj,12:0\"];\n");
		
		sb.append("0 -> 1 [label=3];\n");
		sb.append("0 -> 2 [label=2];\n");
		sb.append("1 -> 11 [label=4];\n");
		sb.append("2 -> 5 [label=5];\n");
		sb.append("2 -> 3 [label=5];\n");
		sb.append("2 -> 4 [label=6];\n");
		sb.append("5 -> 9 [label=3];\n");
		sb.append("5 -> 8 [label=5];\n");
		sb.append("3 -> 6 [label=5];\n");
		sb.append("4 -> 7 [label=4];\n");
		sb.append("4 -> 10 [label=4];\n");
		sb.append("9 -> 11 [label=5];\n");
		sb.append("8 -> 11 [label=5];\n");
		sb.append("6 -> 11 [label=5];\n");
		sb.append("7 -> 11 [label=2];\n");
		sb.append("10 -> 11 [label=3];\n");		
		
		sb.append("}\n");
		System.out.println(sb.toString());
		return sb.toString();
	}
}