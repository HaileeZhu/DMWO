package workflow;

import static java.lang.Math.random;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ServerInfo.VM;
import workflow.*;

public class Workflowbug extends ArrayList<Task>{
	
	private static final long serialVersionUID = 1L;
	//private int workflowId; // The ID of the workflow
	private final String workflowName; // The name of the workflow
	//private int arrivalTime; // The arrival time of the workflow
	private double deadline; // The deadline of the workflow
	private double finishTime; //The finish time the workflow
	//private double makespan; // The makespan of the workflow based on the base execution time of all its tasks
	
	private List<Task> taskList; //The set of tasks
	private List<Task> topoList;
	private int maxParallel;
		
	//public Workflow(int workFlowId, String fileName, int arrivalTime, double makespan, int deadline) {
	public Workflowbug(String fileName) {	
		super();
		Task.resetInternalId();
		//this.workflowId = workflowId;
		this.workflowName = fileName;
		//this.arrivalTime = arrivalTime;
		//this.makespan = makespan;
		//this.deadline = deadline;
		this.finishTime = -1;
		
		try{
			taskList = WorkflowParser.parseXMLFile(fileName);
		}catch(Exception e){	// convert non-RuntimeExceptions to RuntimeException
			throw new RuntimeException("fails to parse " + fileName);
		}
		System.out.println("succeed to read a workflow from " + fileName + "\n");
		
		//topoList = topoSort(taskList.get(0)); //bug
	}
	
	// convert the task list of workflow to a topological sort based on Kahn algorithm; 
	// besides, calculate maximal parallel number and sort edges for each task
	private List<Task> topoSort(Task entry){
		// Empty list that will contain the sorted elements
		//List<Task> topoList = new ArrayList<Task>();	
		//S锟斤拷Set of all nodes with no incoming edges
		//PriorityQueue<Task> S = new PriorityQueue<Task>(10, new Task.ParallelComparator());	
		List<Task> S = new ArrayList<Task>();
		S.add(entry);		

		for(Task task : taskList)	//set topoCount to 0
			task.setTopoCount(0);
		
		this.maxParallel = -1;
		while(S.size()>0){
			maxParallel = Math.max(maxParallel, S.size());
			Task task = S.remove(0);		// remove a node n from S
			//Task task = S.poll();				// remove a node n from S
			topoList.add(task);			        // add n to tail of L
			for(Edge e : task.getOutEdges()){	// for each node m with an edge e from n to m do
				Task t = e.getDestination();
				t.setTopoCount(t.getTopoCount()+1);	//remove edge e from the graph--achieved by setting TopoCount here
				if(t.getTopoCount() == t.getInEdges().size())	//if m has no other incoming edges then
					S.add(t);					// insert m into S			
			}
		}
		// It is a low bound and a larger one may exists
		System.out.println("An approximate value for maximum parallel number: " + maxParallel);  
		
		Edge.EComparator ecForDestination = new Edge.EComparator(true, topoList);//sort edges for each task
		Edge.EComparator ecForSource = new Edge.EComparator(false, topoList);
		for(Task t : taskList){
			Collections.sort(t.getInEdges(), ecForSource);
			Collections.sort(t.getOutEdges(), ecForDestination);
			System.out.println(t.getIdName());
		}
		
		return topoList;
	}
	
	//called by ProLiS and LACO
	public void calcPURank(double theta){
		double speed = VM.SPEEDS[VM.FASTEST];
		for(int j= this.size()-1; j>=0; j--){
			double pURank = 0;	
			Task task = this.get(j);
			for(Edge outEdge : task.getOutEdges()){
				Task child = outEdge.getDestination();
				
				int flag = 1;
				if(theta != Double.MAX_VALUE){		// if theta = Double.MAX_VALUE, flag = 1
					double et = child.getTaskSize() / speed;
					double tt = outEdge.getDataSize() / VM.AVG_BANDWIDTH;
					double d = 1-Math.pow(theta, -et / tt);	//���紫��ʱ��Խ��dȡֵԽ�ӽ���1
					if(d<random())
						flag = 0;
				}
				
				pURank = Math.max(pURank, child.getpURank() + flag * outEdge.getDataSize() / VM.AVG_BANDWIDTH);
			}
			task.setpURank(pURank + task.getTaskSize() / speed);
		}
//		Collections.sort(topoList, new Task.PURankComparator());
//		System.out.println("Topological sort and pURank��");
//		for(Task t : topoList)
//			System.out.println(t.getName() +"\t"+t.getpURank());
	}

	public String getWorkflowName(){
		return workflowName;
	}
/*	
	public void setWorkflowId(int workflowId)
	{
		this.workflowId = workflowId;
	}
	
	public int getWorkflowId(){
		return workflowId;
	}	
	
	public void setArrivalTime(int arrivalTime)
	{
		this.arrivalTime = arrivalTime;
	}
	
	public int getArrivalTime(){
		return arrivalTime;
	}	

	public double getMakespan(){
		return makespan;
	}
	
	public void setMakespan(double makespan)
	{
		this.makespan = makespan;
	}
*/	
	public void setDeadline(double deadline)
	{
		this.deadline = deadline;
	}
	
	public double getDeadline(){
		return deadline;
	}
	
	public void setTaskList(List<Task> list)
	{
		this.taskList = list;
	}
	
	public List<Task> getTaskList(){
		return taskList;
	}

	public void setFinishTime(double finishTime)
	{
		this.finishTime = finishTime;
	}
	
	public double getFinishTime(){
		return finishTime;
	}
}