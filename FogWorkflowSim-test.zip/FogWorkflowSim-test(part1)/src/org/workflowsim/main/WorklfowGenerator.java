package main;

import java.util.List;

import utils.Parameter;
import workflow.Workflow;

public class WorklfowGenerator {

	private static List<Workflow> workflowList; //The set of workflows
	private static int workflowNum = 0; //The number of workflows
	
	public static void main(String[] args) throws Exception 
	{		
		workflowNum = Parameter.workflowNum;
	}

}
