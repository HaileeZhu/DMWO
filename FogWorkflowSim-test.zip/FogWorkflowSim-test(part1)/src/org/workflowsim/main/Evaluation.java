package main;

import methods.Scheduler;
import ServerInfo.Solution;
import methods.*;
import workflow.*;

public class Evaluation {
	
	//because in Java float numbers can not be precisely stored, a very small number E is added before testing whether deadline is met
	public static final double E = 0.0000001; 
	
	//deadline factor.    tight, 0.005:0.005:0.05; loose, 0.05:0.05:0.5
	private static final double DF_START = 0.005, DF_INCR = 0.005, DF_END=0.05;	
	private static final int FILE_INDEX_MAX = 1;
	private static final int[] SIZES = {50,100}; //
	private static final Scheduler[] METHODS = {new ProLiS(1.5)};
	//private static final String[] WORKFLOWS = {"GENOME", "CYBERSHAKE", "LIGO", "MONTAGE"};
	private static final String[] WORKFLOWS = {"DCDS"}; //HEFT, DCDS
	
	static final String WORKFLOW_LOCATION = "D:\\eclipse-workspace\\ZHH\\src\\workflowSamples";
	static final String OUTPUT_LOCATION = "D:\\eclipse-workspace\\ZHH";
	
	public static void main(String[] args)throws Exception {

		
		for(String workflow : WORKFLOWS){
/*			//three dimensions of these two arrays correspond to deadlines, methods, files, respectively
			//double[][][] successResult = new double[deadlineNum][METHODS.length][FILE_INDEX_MAX * SIZES.length]; //success ratio
			//double[][][] NCResult = new double[deadlineNum][METHODS.length][FILE_INDEX_MAX * SIZES.length]; //normalized cost
			double[] refValues = new double[4]; //store cost and time of fastSchedule and cheapSchedule				
			
			for(int di = 0; di<=(DF_END-DF_START)/DF_INCR; di++){	// deadline index
				for(int si = 0; si <SIZES.length; si++){			// size index
					int size = SIZES[si];
					for(int fi = 0;fi<FILE_INDEX_MAX;fi++){			//workflow file index
						String file = WORKFLOW_LOCATION + "\\" + workflow + "\\" + workflow + ".n." + size + "." + fi + ".dax";
						//test(file, di, fi, si, successResult, NCResult, refValues);
						Workflow wf = new Workflow(file);
					}
				}
			}
*/			
			String file = WORKFLOW_LOCATION + "\\" + workflow + "\\" + workflow + ".n.10.0" + ".dax";
			test(file);
			
		}
	}
	
	private static void test(String file){
		
		Workflow wf = new Workflow(file);
		double deadline = 360;
		wf.setDeadline(deadline);
		
		Scheduler method = METHODS[0];
		System.out.println("The current algorithm: " + method.getClass().getCanonicalName() + "\n");
		
		Solution sol = method.schedule(wf);
		if(sol == null)
			//continue;
			System.out.println("NO solution!\n");
		int isSatisfied = sol.calcMakespan()<=deadline + E ? 1 : 0;
		if(sol.validate(wf) == false)
			throw new RuntimeException();
		System.out.println(sol);
		
		
	}
	

}
